Observability airflow dags
**Prerequisite:**
### To ensure that potential secrets or sensitive information do not pushed
    curl https://thoughtworks.github.io/talisman/install.sh > ~/install-talisman.sh
    chmod +x ~/install-talisman.sh
    cd my-git-project
    ~/install-talisman.sh

#### Observability Dags

##### Steps:- 
 * _`cd observability_dags`_
 * **Build the docker image** :-  `./airflow-local-runner.sh build-image`
 * To run airflow webserver:-  `./airflow-local-runner.sh run-airflow`
 * To run tests:-  `./airflow-local-runner.sh run-tests`



