#!/usr/bin/env bash

function init_airflow {
    export AIRFLOW_HOME=/observability-dags
    export AIRFLOW__CORE__LOAD_EXAMPLES=False
    airflow db init # Create/upgrade airflow DB
    airflow users create -r Admin -u airflow -p airflow -e airflow@apache.ru -f airflow -l airflow
    airflow db reset -y
    airflow variables import variables.json

}
function run_tests {
      RESULT_CODE=0 ;
      echo RUN pytest ;
      pytest -o log_cli=true  tests/ || RESULT_CODE=1 ;
      echo RESULT_CODE=$RESULT_CODE ;
      exit $RESULT_CODE
      # The command is something like bash, not an airflow subcommand. Just run it in the right environment.
      exec "$@"
}

case "$1" in
  run-tests)
    init_airflow
    run_tests
    ;;
  run-airflow)
    init_airflow
    airflow scheduler & airflow webserver -p 8090
    ;;
  version)
    airflow "$@"
    ;;
esac