from airflow.operators.python import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

from dags.tasks.send_alert_task import send_alert_task_operator
from dags.tasks.repair_schema_task import repair_schema_task_operator
from datetime import timedelta
from airflow.decorators import dag
import pendulum
from airflow.utils.dates import days_ago
from utility.common_utils import load_job_prop, on_job_failure_callback, on_job_success_callback, dag_status,load_environment_job_prop
from utility.dag_constants import ENV,EVENT_TRANSFORMER_REPROCESSING_PROPS_PATH, JOB_SCHEDULE, TRANSFORMER_VIRTUAL_CLUSTER_ID, \
    JOB_ROLE_ARN, EMR_RELEASE_LABEL, REPAIR_SCHEMA_PROPS_PATH
from utility.spark_param_generator import generate_monitoring_args, generate_job_driver_args,get_product_wise_args
from dags.tasks.emr_container_operator_task import create_EMROperator


variable_dict, env_var_dict, job_dict, spark_entry_point_arg_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
    EVENT_TRANSFORMER_REPROCESSING_PROPS_PATH)

env = spark_entry_point_arg_dict[ENV]

environment_configs = load_environment_job_prop(variable_dict,
                                                env_var_dict,
                                                EVENT_TRANSFORMER_REPROCESSING_PROPS_PATH,
                                                env)

product_list = ""
job_driver_arg = get_product_wise_args(product_list, spark_entry_point_arg_dict, spark_conf_dict,
                                             job_dict, environment_configs)

configuration_overrides_arg = generate_monitoring_args(monitor_conf_dict)

spark_entry_point_arg_dict["topicsToFilter"] = job_dict["topicsToFilterBatch1"]
spark_entry_point_arg_dict["productsToFilter"] = job_dict["productsToFilterBatch1"]
job_driver_arg_group_1 = get_product_wise_args(product_list, spark_entry_point_arg_dict, spark_conf_dict,
                                             job_dict, environment_configs)

spark_entry_point_arg_dict["topicsToFilter"] = job_dict["topicsToFilterBatch2"]
spark_entry_point_arg_dict["productsToFilter"] = job_dict["productsToFilterBatch2"]
job_driver_arg_group_2 = get_product_wise_args(product_list, spark_entry_point_arg_dict, spark_conf_dict,
                                             job_dict, environment_configs)

schedule_interval = job_dict[JOB_SCHEDULE]

@dag(dag_id='observability_event_transformer_reprocessing',
     dagrun_timeout=timedelta(minutes=180),
     start_date=days_ago(1).astimezone(pendulum.timezone("Asia/Calcutta")),
     schedule_interval=schedule_interval,
     catchup=False,
     max_active_runs=1,
     tags=["emr_containers"])

def event_transformer_etl():

    event_transformer_etl_group_1 = create_EMROperator("event_transformer_etl_reprocessing_group_1",
                                                         variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                                         variable_dict[JOB_ROLE_ARN],
                                                         variable_dict[EMR_RELEASE_LABEL],
                                                         job_driver_arg_group_1,
                                                         configuration_overrides_arg,
                                                         "reprocessing_transformer_group_1",
                                                         on_job_failure_callback,
                                                         on_job_success_callback
                                                         )

    event_transformer_etl_group_2 = create_EMROperator("event_transformer_etl_reprocessing_group_2",
                                                         variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                                         variable_dict[JOB_ROLE_ARN],
                                                         variable_dict[EMR_RELEASE_LABEL],
                                                         job_driver_arg_group_2,
                                                         configuration_overrides_arg,
                                                         "reprocessing_transformer_group_2",
                                                         on_job_failure_callback,
                                                         on_job_success_callback
                                                         )

    repair_schema = repair_schema_task_operator(spark_entry_point_arg_dict,
                                                configuration_overrides_arg,
                                                variable_dict,
                                                env_var_dict,
                                                REPAIR_SCHEMA_PROPS_PATH)

    event_transformer_etl_group_1 >> event_transformer_etl_group_2 >> repair_schema

    # TODO : Use EmailOperator
    send_email = send_alert_task_operator(spark_entry_point_arg_dict,
                                          configuration_overrides_arg,
                                          variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                          variable_dict, env_var_dict)

    dag_status_check = PythonOperator(task_id="dag_status", python_callable=dag_status,
                                      trigger_rule=TriggerRule.ALL_DONE,
                                      provide_context=True)

    [event_transformer_etl_group_1, event_transformer_etl_group_2, repair_schema] >> send_email >> dag_status_check


etl_dag = event_transformer_etl()
