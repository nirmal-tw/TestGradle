from airflow.operators.python import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

from dags.tasks.send_alert_task import send_alert_task_operator
from dags.tasks.repair_schema_task import repair_schema_task_operator
from datetime import timedelta
import pendulum
from airflow.decorators import dag
from airflow.utils.dates import days_ago
from utility.common_utils import load_job_prop, on_job_failure_callback, on_job_success_callback, dag_status
from utility.spark_param_generator import generate_monitoring_args, generate_job_driver_args
from utility.dag_constants import DLQ_TRANSFORMER_PROPS_PATH, JOB_SCHEDULE, TRANSFORMER_VIRTUAL_CLUSTER_ID, \
    JOB_ROLE_ARN, \
    REPAIR_SCHEMA_PROPS_PATH, EMR_RELEASE_LABEL
from dags.tasks.emr_container_operator_task import create_EMROperator

variable_dict, env_var_dict, job_dict, spark_entry_point_arg_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
    DLQ_TRANSFORMER_PROPS_PATH)

configuration_overrides_arg = generate_monitoring_args(monitor_conf_dict)

schedule_interval = job_dict[JOB_SCHEDULE]


@dag(dag_id='observability_dlq_transformer',
     dagrun_timeout=timedelta(minutes=60),
     start_date=days_ago(1).astimezone(pendulum.timezone("Asia/Calcutta")),
     schedule_interval=schedule_interval,
     catchup=False,
     max_active_runs=1,
     tags=["emr_containers"])
def dlq_transformer_etl():
    dlq_transformer_etl = create_EMROperator("dlq_transformer_etl",
                                             variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                             variable_dict[JOB_ROLE_ARN],
                                             variable_dict[EMR_RELEASE_LABEL],
                                             generate_job_driver_args(spark_entry_point_arg_dict, spark_conf_dict,
                                                                      job_dict),
                                             configuration_overrides_arg,
                                             "dlq_transformer",
                                             on_job_failure_callback,
                                             on_job_success_callback
                                             )

    repair_schema = repair_schema_task_operator(spark_entry_point_arg_dict,
                                                configuration_overrides_arg,
                                                variable_dict,
                                                env_var_dict,
                                                REPAIR_SCHEMA_PROPS_PATH)

    dlq_transformer_etl >> repair_schema

    # TODO : Use EmailOperator
    send_email = send_alert_task_operator(spark_entry_point_arg_dict,
                                          configuration_overrides_arg,
                                          variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                          variable_dict, env_var_dict)

    dag_status_check = PythonOperator(task_id="dag_status", python_callable=dag_status,
                                 trigger_rule=TriggerRule.ALL_DONE,
                                 provide_context=True)

    [dlq_transformer_etl, repair_schema] >> send_email >> dag_status_check


etl_dag = dlq_transformer_etl()
