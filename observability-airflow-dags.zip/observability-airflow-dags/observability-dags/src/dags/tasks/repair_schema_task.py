from utility.common_utils import init_repair_prop,on_job_failure_callback,on_job_success_callback
from utility.dag_constants import TRANSFORMER_VIRTUAL_CLUSTER_ID,JOB_ROLE_ARN,EMR_RELEASE_LABEL
from utility.spark_param_generator import generate_job_driver_args
from dags.tasks.emr_container_operator_task import create_EMROperator


def get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict) :

     spark_entry_point_arg_dict["parentJobName"] = spark_entry_point_arg_dict["jobName"]
     spark_entry_point_arg_dict["jobName"]= "repair_schema"

     return generate_job_driver_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict)



def repair_schema_task_operator(spark_entry_point_arg_dict, configuration_overrides_arg, variable_dict,env_var_dict,props_path):
    repair_job_dict, repair_spark_conf_dict = init_repair_prop(variable_dict, env_var_dict,props_path)

    repair_schema = create_EMROperator("repair_schema",
                                       variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                       variable_dict[JOB_ROLE_ARN],
                                       variable_dict[EMR_RELEASE_LABEL],
                                       get_args(spark_entry_point_arg_dict,repair_spark_conf_dict, repair_job_dict),
                                       configuration_overrides_arg,
                                                         spark_entry_point_arg_dict["parentJobName"]+"_repair",
                                       on_job_failure_callback,
                                       on_job_success_callback
                                       )

    return repair_schema