from airflow.utils.trigger_rule import TriggerRule

from emr_containers.operators.emr_containers import EMRContainerOperator

def create_EMROperator(task_id, virtual_cluster_id, job_role_arn, emr_release_label, job_driver_arg, configuration_overrides_arg, name, failure_callback, success_callback, trigger_rule=TriggerRule.ALL_DONE):

    emrOpertorObject = EMRContainerOperator(
        task_id=task_id,
        virtual_cluster_id=virtual_cluster_id,
        execution_role_arn=job_role_arn,
        release_label=emr_release_label,
        job_driver=job_driver_arg,
        configuration_overrides=configuration_overrides_arg,
        name=name,
        on_failure_callback=failure_callback,
        on_success_callback=success_callback,
        trigger_rule=trigger_rule
    )

    return emrOpertorObject