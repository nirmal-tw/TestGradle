from airflow.utils.trigger_rule import TriggerRule
from emr_containers.operators.emr_containers import EMRContainerOperator
from utility.common_utils import init_alert_prop, on_job_success_callback
from utility.dag_constants import NUDGE_VIRTUAL_CLUSTER_ID, JOB_ROLE_ARN, EMR_RELEASE_LABEL
from utility.spark_param_generator import generate_job_driver_args


def get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict):
    spark_entry_point_arg_new_dict = {}
    spark_entry_point_arg_new_dict["env"] = spark_entry_point_arg_dict["env"]
    spark_entry_point_arg_new_dict["emailPropertiesFile"] = spark_entry_point_arg_dict["emailPropertiesFile"]
    spark_entry_point_arg_new_dict["exceptionMessage"] = "{{ ti.xcom_pull(key='exceptionMessage') }}"
    spark_entry_point_arg_new_dict["workflowId"] = "{{ ti.xcom_pull(key='workflowId') }}"
    spark_entry_point_arg_new_dict["workflowName"] = "{{ ti.xcom_pull(key='workflowName') }}"
    spark_entry_point_arg_new_dict["failedAction"] = "{{ ti.xcom_pull(key='failedAction') }}"
    return generate_job_driver_args(spark_entry_point_arg_new_dict, alert_spark_conf_dict, alert_job_dict)


def send_alert_task_operator(spark_entry_point_arg_dict, configuration_overrides_arg, virtual_cluster_id, variable_dict,
                             env_var_dict):
    alert_job_dict, alert_spark_conf_dict = init_alert_prop(variable_dict, env_var_dict)

    send_email = EMRContainerOperator(
        task_id="send_email",
        trigger_rule=TriggerRule.ONE_FAILED,
        virtual_cluster_id=virtual_cluster_id,
        execution_role_arn=variable_dict[JOB_ROLE_ARN],
        release_label=variable_dict[EMR_RELEASE_LABEL],
        job_driver=get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict),
        configuration_overrides=configuration_overrides_arg,
        name="{{ ti.xcom_pull(key='workflowName') }}"+"_notifier",
        on_success_callback=on_job_success_callback
    )
    return send_email
