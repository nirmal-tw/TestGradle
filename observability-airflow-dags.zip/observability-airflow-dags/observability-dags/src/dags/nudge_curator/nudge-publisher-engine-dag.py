from airflow.operators.python import PythonOperator, ShortCircuitOperator
from airflow.utils.trigger_rule import TriggerRule

from dags.tasks.send_alert_task import send_alert_task_operator
from datetime import timedelta
import pendulum
from airflow.decorators import dag
from airflow.utils.dates import days_ago
from utility.common_utils import load_job_prop,on_job_failure_callback, on_job_success_callback, dag_status
from utility.dag_constants import NUDGE_PUBLISHER_ENGINE_PROPS_PATH, JOB_SCHEDULE, NUDGE_VIRTUAL_CLUSTER_ID, JOB_ROLE_ARN, \
    EMR_RELEASE_LABEL, TRANSFORMER_VIRTUAL_CLUSTER_ID
from utility.spark_param_generator import generate_job_driver_args,generate_monitoring_args
from dags.tasks.emr_container_operator_task import create_EMROperator
variable_dict, env_var_dict, job_dict, spark_entry_point_arg_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
    NUDGE_PUBLISHER_ENGINE_PROPS_PATH)

job_driver_arg = generate_job_driver_args(spark_entry_point_arg_dict,spark_conf_dict,job_dict)

configuration_overrides_arg = generate_monitoring_args(monitor_conf_dict)

schedule_interval = job_dict[JOB_SCHEDULE]

@dag(dag_id='nudge_publisher_engine',
     dagrun_timeout=timedelta(minutes=15),
     start_date=days_ago(1).astimezone(pendulum.timezone("Asia/Calcutta")),
     schedule_interval=schedule_interval,
     catchup=False,
     max_active_runs=1,
     tags=['emr_containers'])

def nudge_publisher_etl():

    nudge_publisher_etl = create_EMROperator("nudge_publisher_etl",
                                           variable_dict[NUDGE_VIRTUAL_CLUSTER_ID],
                                           variable_dict[JOB_ROLE_ARN],
                                           variable_dict[EMR_RELEASE_LABEL],
                                           job_driver_arg,
                                           configuration_overrides_arg,
                                            "nudge_publisher",
                                           on_job_failure_callback,
                                           on_job_success_callback
                                           )

    # TODO : Use EmailOperator
    send_email = send_alert_task_operator(spark_entry_point_arg_dict,
                                          configuration_overrides_arg,
                                          variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                          variable_dict,
                                          env_var_dict)

    dag_status_check = PythonOperator(task_id="dag_status", python_callable=dag_status,
                                      trigger_rule=TriggerRule.ALL_DONE,
                                      provide_context=True)

    nudge_publisher_etl >> send_email >> dag_status_check


etl_dag = nudge_publisher_etl()
