from airflow.operators.python import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

from dags.tasks.send_alert_task import send_alert_task_operator
from datetime import timedelta
import pendulum
from airflow.decorators import dag
from airflow.utils.dates import days_ago

from emr_containers.operators.emr_containers import EMRContainerOperator
from utility.common_utils import load_job_prop, on_job_failure_callback, on_job_success_callback, dag_status, \
    load_environment_job_prop
from utility.dag_constants import ENV, NUDGE_CURATOR_ENGINE_PROPS_PATH, JOB_SCHEDULE, NUDGE_VIRTUAL_CLUSTER_ID, \
    JOB_ROLE_ARN, \
    EMR_RELEASE_LABEL, TRANSFORMER_VIRTUAL_CLUSTER_ID, PRODUCT_LIST
from utility.spark_param_generator import generate_job_driver_args, generate_monitoring_args, get_product_wise_args
from airflow.models.baseoperator import chain

variable_dict, env_var_dict, job_dict, spark_entry_point_arg_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
    NUDGE_CURATOR_ENGINE_PROPS_PATH)

job_driver_arg = generate_job_driver_args(spark_entry_point_arg_dict,spark_conf_dict,job_dict)

env = spark_entry_point_arg_dict[ENV]

environment_configs = load_environment_job_prop(variable_dict,
                                                env_var_dict,
                                                NUDGE_CURATOR_ENGINE_PROPS_PATH,
                                                env)

configuration_overrides_arg = generate_monitoring_args(monitor_conf_dict)

schedule_interval = job_dict[JOB_SCHEDULE]
product_list = job_dict[PRODUCT_LIST].split(",")


def get_nudge_task_list(product_list):
    tasks = []
    for product in product_list:
        spark_entry_point_arg_dict["productCodes"] = product
        task = EMRContainerOperator(
            task_id="nudge_task_" + product,
            virtual_cluster_id=variable_dict[NUDGE_VIRTUAL_CLUSTER_ID],
            execution_role_arn=variable_dict[JOB_ROLE_ARN],
            release_label=variable_dict[EMR_RELEASE_LABEL],
            job_driver=get_product_wise_args(product, spark_entry_point_arg_dict, spark_conf_dict,
                                             job_dict, environment_configs),
            configuration_overrides=configuration_overrides_arg,
            name=product + "_nudge_task",
            on_failure_callback=on_job_failure_callback,
            on_success_callback=on_job_success_callback,
            trigger_rule=TriggerRule.ALL_DONE
        )
        tasks.append(task)
    return tasks


@dag(dag_id='nudge_curator_engine',
     dagrun_timeout=timedelta(minutes=15),
     start_date=days_ago(1).astimezone(pendulum.timezone("Asia/Calcutta")),
     schedule_interval=schedule_interval,
     catchup=False,
     max_active_runs=1,
     concurrency=8,
     tags=['emr_containers'])
def nudge_curator_etl():
    tasks = get_nudge_task_list(product_list)

    chain(tasks)

    # TODO : Use EmailOperator
    send_email = send_alert_task_operator(spark_entry_point_arg_dict,
                                          configuration_overrides_arg,
                                          variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID],
                                          variable_dict,
                                          env_var_dict)

    dag_status_check = PythonOperator(task_id="dag_status", python_callable=dag_status,
                                      trigger_rule=TriggerRule.ALL_DONE,
                                      provide_context=True)

    tasks >> send_email >> dag_status_check


etl_dag = nudge_curator_etl()
