from utility.common_utils import read_value_from_properties


def generate_spark_entry_args(spark_entry_point_arg_dict):
    return ['{0}={1}'.format(element[0], element[1]) for element in spark_entry_point_arg_dict.items()]


def generate_spark_submit_params(spark_conf_dict, job_dict):
    params = " --class {0}".format(read_value_from_properties(job_dict, "className"))
    params += " --deploy-mode {0}".format(read_value_from_properties(job_dict, "deployMode"))
    params += " --jars {0}".format(read_value_from_properties(job_dict, "jars"))
    for conf in spark_conf_dict.items():
        params += " --conf {0}={1}".format(conf[0], conf[1])

    return params


def generate_job_driver_args(spark_entry_point_arg_dict, spark_conf_dict, job_dict):
    spark_entry_point_arg_dict["jobId"] = "{{ dag.dag_id }}"+"-"+"{{ run_id }}"
    return {
        "sparkSubmitJobDriver": {
            "entryPoint": read_value_from_properties(job_dict, "entryPoint"),
            "entryPointArguments": generate_spark_entry_args(spark_entry_point_arg_dict),
            "sparkSubmitParameters": generate_spark_submit_params(spark_conf_dict, job_dict)
        }
    }


def generate_monitoring_args(monitor_conf_dict):
    monitoringConfiguration = {}
    cloudWatchMonitoringConfiguration = {
                "logGroupName": read_value_from_properties(monitor_conf_dict, "logGroupName"),
                "logStreamNamePrefix": read_value_from_properties(monitor_conf_dict, "logGroupName")
            }
    s3MonitoringConfiguration = {
                "logUri": read_value_from_properties(monitor_conf_dict, "logUri")
            }
    #TODO : Get rid of nested if-else
    if read_value_from_properties(monitor_conf_dict,"isEnabled").upper()=="TRUE":
        if read_value_from_properties(monitor_conf_dict,"cloudWatchEnabled").upper()=="TRUE":
            monitoringConfiguration["cloudWatchMonitoringConfiguration"] = cloudWatchMonitoringConfiguration
        if read_value_from_properties(monitor_conf_dict,"s3Enabled").upper()=="TRUE":
            monitoringConfiguration["s3MonitoringConfiguration"] = s3MonitoringConfiguration
        if read_value_from_properties(monitor_conf_dict,"cloudWatchEnabled").upper()=="FALSE" and read_value_from_properties(monitor_conf_dict,"s3Enabled").upper()=="FALSE":
            raise ValueError("Monitoring is enabled but both CloudWatch and S3 are DISABLED")
    else:
        return monitoringConfiguration

    return {"monitoringConfiguration": monitoringConfiguration}


def get_product_wise_args(product_type, spark_entry_point_arg_dict, spark_conf_dict, job_dict, environment_configs):
    spark_entry_point_arg_dict["productType"] = product_type
    if (environment_configs.has_section(("spark-conf-"+product_type))):
        spark_conf_env_dict = dict(environment_configs.items(("spark-conf-"+product_type)))
    else:
        spark_conf_env_dict = dict(environment_configs.items("spark-conf-default"))

    spark_conf_dict.update(spark_conf_env_dict)
    job_driver_arg = generate_job_driver_args(spark_entry_point_arg_dict, spark_conf_dict, job_dict)

    return {
        "sparkSubmitJobDriver": {
            "entryPoint": read_value_from_properties(job_dict, "entryPoint"),
            "entryPointArguments": generate_spark_entry_args(spark_entry_point_arg_dict),
            "sparkSubmitParameters": generate_spark_submit_params(spark_conf_dict, job_dict)
        }
    }

    return job_driver_arg
