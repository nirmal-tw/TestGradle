import os
import traceback

from airflow.utils.state import State
from airflow.models import Variable

from utility.dag_constants import NUDGE_VIRTUAL_CLUSTER_ID, JOB_ROLE_ARN, EMR_RELEASE_LABEL, OBSERVABILITY_S3_BUCKET, \
    PROPERTIES_PATH_FILE_SYSTEM, ENVIRONEMENT, BASE_PATH, SERVICE_USER, \
    HIVE_METASTORE, JOB_PARAMS, SPARK_ARGS, SPARK_CONF, MONITORING_CONF, TRANSFORMER_VIRTUAL_CLUSTER_ID
from utility.file_utils import read_configs


def read_value_from_properties(dict, key):
    return dict[key]


def get_airflow_variable(key):
    return Variable.get(key)


def get_variable_dictionary():
    variable_dict = {}

    variable_dict[NUDGE_VIRTUAL_CLUSTER_ID] = get_airflow_variable(NUDGE_VIRTUAL_CLUSTER_ID)
    variable_dict[TRANSFORMER_VIRTUAL_CLUSTER_ID] = get_airflow_variable(TRANSFORMER_VIRTUAL_CLUSTER_ID)
    variable_dict[JOB_ROLE_ARN] = get_airflow_variable(JOB_ROLE_ARN)
    variable_dict[EMR_RELEASE_LABEL] = get_airflow_variable(EMR_RELEASE_LABEL)
    variable_dict[OBSERVABILITY_S3_BUCKET] = get_airflow_variable(OBSERVABILITY_S3_BUCKET)
    variable_dict[PROPERTIES_PATH_FILE_SYSTEM] = get_airflow_variable(PROPERTIES_PATH_FILE_SYSTEM)

    return variable_dict


def get_variable_dictionary_for_environment():
    variable_dict = {}
    variable_dict[ENVIRONEMENT] = get_airflow_variable(ENVIRONEMENT)
    variable_dict[BASE_PATH] = get_airflow_variable(BASE_PATH)
    variable_dict[SERVICE_USER] = get_airflow_variable(SERVICE_USER)
    variable_dict[HIVE_METASTORE] = get_airflow_variable(HIVE_METASTORE)
    return variable_dict


def on_job_failure_callback(context):
    task = context['task_instance']

    exception = context.get('exception')
    formatted_exception = ''.join(
        traceback.format_exception(etype=type(exception),
                                   value=exception,
                                   tb=exception.__traceback__)).strip()

    dag_name = context['task_instance_key_str'].split('__')[0]
    action = context['task_instance_key_str'].split('__')[1]

    task.xcom_push(key="exceptionMessage", value=formatted_exception)
    task.xcom_push(key="workflowId", value=str(task))
    task.xcom_push(key="workflowName", value=dag_name)
    task.xcom_push(key="failedAction", value=action)
    return formatted_exception


def on_job_success_callback(context):
    """Define custom success notification behavior"""
    dag_context = context.get('dag_run')
    task_instances = dag_context.get_task_instances()

    return str.format("Inside job success.These task instances succeeded : {0}", task_instances)


def load_job_prop(property_path):
    variable_dict = get_variable_dictionary()
    env_var_dict = get_variable_dictionary_for_environment()
    config = read_configs(property_path, variable_dict, env_var_dict)

    job_dict = dict(config.items(JOB_PARAMS))
    spark_args_dict = dict(config.items(SPARK_ARGS))
    spark_conf_dict = dict(config.items(SPARK_CONF))
    monitor_conf_dict = dict(config.items(MONITORING_CONF))

    for key in env_var_dict.keys():
        spark_args_dict.pop(key)

    return variable_dict, env_var_dict, job_dict, spark_args_dict, spark_conf_dict, monitor_conf_dict


def load_environment_job_prop(variable_dict, env_var_dict, property_path, env):
    configuration_file_key = enviornment_based_property_file_name(property_path, env)
    config = read_configs(configuration_file_key, variable_dict, env_var_dict)
    return config


def enviornment_based_property_file_name(property_file_path, env):
    extension = os.path.splitext(property_file_path)[1]
    env_str = "." + env
    index = property_file_path.index(extension)
    formatted_path = property_file_path[:index] + env_str + property_file_path[index:]
    return formatted_path


def init_repair_prop(variable_dict, env_var_dict, props_path):
    configuration_file_key = props_path
    config = read_configs(configuration_file_key, variable_dict, env_var_dict)
    job_dict = dict(config.items(JOB_PARAMS))
    spark_conf_dict = dict(config.items(SPARK_CONF))
    return job_dict, spark_conf_dict


def init_alert_prop(variable_dict, env_var_dict):
    configuration_file_key = "resources/alerts/job.properties"
    config = read_configs(configuration_file_key, variable_dict, env_var_dict)
    job_dict = dict(config.items(JOB_PARAMS))
    spark_conf_dict = dict(config.items(SPARK_CONF))
    return job_dict, spark_conf_dict


def dag_status(**kwargs):
    for task_instance in kwargs['dag_run'].get_task_instances():
        if task_instance.current_state() == State.FAILED and task_instance.task_id != kwargs['task_instance'].task_id:
            raise Exception("Task {} failed. Failing this DAG run".format(task_instance.task_id))
