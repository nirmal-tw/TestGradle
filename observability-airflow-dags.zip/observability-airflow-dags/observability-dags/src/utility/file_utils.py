import io
from configparser import ConfigParser

import boto3

from utility.dag_constants import PROPERTIES_PATH_FILE_SYSTEM, BASE_PATH


class CaseConfigParser(ConfigParser):
    def optionxform(self, optionstr):
        return optionstr


def read_configs(conf_file_name, variable_dict, env_dict):
    file_system = variable_dict[PROPERTIES_PATH_FILE_SYSTEM]
    if file_system == "s3":
        return read_from_s3(conf_file_name, env_dict)
    elif file_system == "local":
        return read_from_local(conf_file_name, env_dict)


def read_from_s3(conf_file_name, env_dict):
    file_path = env_dict[BASE_PATH] + "/" + conf_file_name
    bucket, key = split_s3_path(file_path)

    s3_boto = boto3.client('s3')

    obj = s3_boto.get_object(Bucket=bucket, Key=key)
    result = obj['Body'].read().decode()
    config = CaseConfigParser(env_dict)
    config.read_file(io.StringIO(result))
    return config


def read_from_local(conf_file_name, env_dict):
    base_path = env_dict[BASE_PATH]
    file_name = base_path + conf_file_name
    config = CaseConfigParser(env_dict)
    config.read(file_name)
    return config


def split_s3_path(s3_path):
    path_parts = s3_path.replace("s3://", "").replace("s3a://", "").split("/")
    bucket = path_parts.pop(0)
    key = "/".join(path_parts)
    return bucket, key
