#!/usr/bin/env bash

build_image() {
    docker-compose build
}

case "$1" in
build-image)
   build_image
   ;;
run-tests)
  docker-compose -f docker-compose-run-tests.yaml up
  ;;
run-airflow)
  docker-compose -f docker-compose.yaml up
   ;;

*)
   echo "No command specified: Choose from |run-tests|run-airflow|build-image"

   ;;
esac

