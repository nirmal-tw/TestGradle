import pytest

from airflow.models import DagBag


@pytest.fixture()
def dagbag():
    return DagBag(include_examples=False)
def test_dag_loaded(dagbag):
     dag = dagbag.dags["observability_metric_transformer"]
     assert dagbag.import_errors == {}
     assert dag is not None

def test_number_of_tasks(dagbag):
     dag = dagbag.get_dag(dag_id="observability_metric_transformer")
     assert len(dag.tasks) == 4

def test_task_name_seq(dagbag) :
     dag = dagbag.get_dag(dag_id="observability_metric_transformer")
     tasks = dag.tasks
     task_ids = list(map(lambda task: task.task_id, tasks))

     assert task_ids == ['metrics_transformer_etl','repair_schema', 'send_email', 'dag_status']

def test_dependencies_of_etl_task(dagbag):
     dag = dagbag.get_dag(dag_id="observability_metric_transformer")
     task = dag.get_task('metrics_transformer_etl')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert upstream_task_ids == []
     assert sorted(downstream_task_ids) == ['repair_schema', 'send_email']

def test_dependencies_of_repair_task(dagbag):
     dag = dagbag.get_dag(dag_id="observability_metric_transformer")
     task = dag.get_task('repair_schema')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert upstream_task_ids == ['metrics_transformer_etl']
     assert sorted(downstream_task_ids) == ['send_email']

