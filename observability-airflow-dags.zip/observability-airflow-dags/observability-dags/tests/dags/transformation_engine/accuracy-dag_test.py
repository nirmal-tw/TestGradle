import pytest

from airflow.models import DagBag


productList = "las,personal,four_wheeler_personal,credit_card,home,overdraft,offer,al_top_up,two_wheeler_personal".split(",")

@pytest.fixture()
def dagbag():
    return DagBag(include_examples=False)

def test_dag_loaded(dagbag):
     dag = dagbag.dags["observability_accuracy"]
     assert dagbag.import_errors == {}
     assert dag is not None

def test_number_of_tasks(dagbag):
     dag = dagbag.get_dag(dag_id="observability_accuracy")
     assert len(dag.tasks) == len(productList)+1+1

def test_task_name_seq(dagbag) :
     dag = dagbag.get_dag(dag_id="observability_accuracy")
     tasks = dag.tasks
     task_ids = list(map(lambda task: task.task_id, tasks))
     expected_tasks = list(map(lambda product : "accuracy_task_"+product, productList))

     assert task_ids == [*expected_tasks, 'send_email', 'dag_status']

def test_dependencies_of_accuracy_task(dagbag):
     dag = dagbag.get_dag(dag_id="observability_accuracy")
     task = dag.get_task('accuracy_task_'+productList[1])
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))
     assert upstream_task_ids == ['accuracy_task_'+productList[0]]
     assert sorted(downstream_task_ids) == sorted(['accuracy_task_'+productList[2], 'send_email'])

def test_dependencies_of_email_task(dagbag):
     dag = dagbag.get_dag(dag_id="observability_accuracy")
     task = dag.get_task('send_email')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     expected_upstream_tasks = list(map(lambda product : "accuracy_task_"+product, productList))
     assert sorted(upstream_task_ids) == sorted([*expected_upstream_tasks])
     assert downstream_task_ids == ['dag_status']

