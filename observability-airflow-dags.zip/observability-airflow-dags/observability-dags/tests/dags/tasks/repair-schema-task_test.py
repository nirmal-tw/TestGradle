from dags.tasks.repair_schema_task import get_args

def test_get_args_with_all_values():
    spark_entry_point_arg_dict = {'env': 'sit', 'jobId': 'repair_schema_job', 'jobName': 'event_transformer',
                                  "statusFilePath":"some-value","dbName":"some-value",
                                  "repairSchemaTables":"some-value","partitionColumns":"some-value",
                                  "hiveMetastoreIp":"some-value","baseDir":"some-value"}

    alert_spark_conf_dict = {'partitionMode': 'dynamic', 'interval': '1h'}

    alert_job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}
    assert get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict) == {'sparkSubmitJobDriver': {'entryPoint': 'job.jar', 'entryPointArguments': ['env=sit', 'jobId={{ dag.dag_id }}-{{ run_id }}', 'jobName=repair_schema', 'statusFilePath=some-value', 'dbName=some-value', 'repairSchemaTables=some-value', 'partitionColumns=some-value', 'hiveMetastoreIp=some-value', 'baseDir=some-value', 'parentJobName=event_transformer'], 'sparkSubmitParameters': ' --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf partitionMode=dynamic --conf interval=1h'}}

def test_get_args_with_no_partitionColumns():
    spark_entry_point_arg_dict = {'env': 'sit', 'jobId': 'repair_schema_job', 'jobName': 'event_transformer',
                                  "statusFilePath":"some-value","dbName":"some-value",
                                  "repairSchemaTables":"some-value",
                                  "hiveMetastoreIp":"some-value","baseDir":"some-value"}

    alert_spark_conf_dict = {'partitionMode': 'dynamic', 'interval': '1h'}

    alert_job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}
    assert get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict) == {'sparkSubmitJobDriver': {'entryPoint': 'job.jar', 'entryPointArguments': ['env=sit', 'jobId={{ dag.dag_id }}-{{ run_id }}', 'jobName=repair_schema',  'statusFilePath=some-value', 'dbName=some-value', 'repairSchemaTables=some-value', 'hiveMetastoreIp=some-value', 'baseDir=some-value', 'parentJobName=event_transformer'], 'sparkSubmitParameters': ' --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf partitionMode=dynamic --conf interval=1h'}}


