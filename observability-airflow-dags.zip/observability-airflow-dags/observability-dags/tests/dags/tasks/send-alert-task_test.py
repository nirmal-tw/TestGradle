from dags.tasks.send_alert_task import get_args

def test_get_args_with_all_values():
    spark_entry_point_arg_dict = {'env': 'sit', 'emailPropertiesFile': 'email.properties', 'exceptionMessage': 'Failed',
                                  "workflowId":"test-workflow-id","workflowName":"test","failedAction":"action"}

    alert_spark_conf_dict = {'partitionMode': 'dynamic', 'interval': '1h'}

    alert_job_dict = {'className': '=com.axis.observability.alert.Notifier', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}

    expected_message = {'sparkSubmitJobDriver': {'entryPoint': 'job.jar', 'entryPointArguments': ['env=sit', 'emailPropertiesFile=email.properties', "exceptionMessage={{ ti.xcom_pull(key='exceptionMessage') }}", "workflowId={{ ti.xcom_pull(key='workflowId') }}", "workflowName={{ ti.xcom_pull(key='workflowName') }}", "failedAction={{ ti.xcom_pull(key='failedAction') }}", 'jobId={{ dag.dag_id }}-{{ run_id }}'], 'sparkSubmitParameters': ' --class =com.axis.observability.alert.Notifier --deploy-mode cluster --jars lib/*.jar --conf partitionMode=dynamic --conf interval=1h'}}

    assert get_args(spark_entry_point_arg_dict, alert_spark_conf_dict, alert_job_dict) == expected_message


