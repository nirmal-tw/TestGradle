from dags.tasks.emr_container_operator_task import create_EMROperator
from emr_containers.operators.emr_containers import EMRContainerOperator
from utility.common_utils import on_job_failure_callback, on_job_success_callback, \
    load_job_prop
from utility.dag_constants import EVENT_TRANSFORMER_PROPS_PATH, NUDGE_VIRTUAL_CLUSTER_ID, JOB_ROLE_ARN, EMR_RELEASE_LABEL
from utility.spark_param_generator import generate_job_driver_args, generate_monitoring_args


def test_create_EMRContainer_operator():

    variable_dict, env_var_dict, job_dict, spark_entry_point_arg_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
        EVENT_TRANSFORMER_PROPS_PATH)

    job_driver_arg = generate_job_driver_args(spark_entry_point_arg_dict, spark_conf_dict, job_dict)
    configuration_overrides_arg = generate_monitoring_args(monitor_conf_dict)

    test_event_transformer_etl = create_EMROperator("event_transformer_etl",
                                                    variable_dict[NUDGE_VIRTUAL_CLUSTER_ID],
                                                    variable_dict[JOB_ROLE_ARN],
                                                    variable_dict[EMR_RELEASE_LABEL],
                                                    job_driver_arg,
                                                    configuration_overrides_arg,
                                                         "TransformationDriver",
                                                    on_job_failure_callback,
                                                    on_job_success_callback
                                                    )

    event_transformer_etl = EMRContainerOperator(
        task_id="event_transformer_etl",
        virtual_cluster_id=variable_dict[NUDGE_VIRTUAL_CLUSTER_ID],
        execution_role_arn=variable_dict[JOB_ROLE_ARN],
        release_label=variable_dict[EMR_RELEASE_LABEL],
        job_driver=job_driver_arg,
        configuration_overrides=configuration_overrides_arg,
        name="TransformationDriver",
        on_failure_callback=on_job_failure_callback,
        on_success_callback=on_job_success_callback
    )

    assert test_event_transformer_etl == event_transformer_etl