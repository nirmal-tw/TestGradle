import pytest

from airflow.models import DagBag


@pytest.fixture()
def dagbag():
    return DagBag(include_examples=False)
def test_dag_loaded(dagbag):
     dag = dagbag.dags["nudge_curator_engine"]
     assert dagbag.import_errors == {}
     assert dag is not None

def test_number_of_tasks(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_curator_engine")
     assert len(dag.tasks) == 6

def test_task_name_seq(dagbag) :
     dag = dagbag.get_dag(dag_id="nudge_curator_engine")
     tasks = dag.tasks
     task_ids = list(map(lambda task: task.task_id, tasks))

     assert task_ids == ['nudge_task_personal','nudge_task_credit_card','nudge_task_las','nudge_task_overdraft','send_email', 'dag_status']

def test_dependencies_of_etl_task(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_curator_engine")
     task = dag.get_task('nudge_task_overdraft')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert upstream_task_ids == []
     assert sorted(downstream_task_ids) == ['send_email']

def test_dependencies_of_send_email_task(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_curator_engine")
     task = dag.get_task('send_email')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert sorted(upstream_task_ids) == sorted(['nudge_task_personal','nudge_task_credit_card','nudge_task_las','nudge_task_overdraft'])
     assert sorted(downstream_task_ids) == ['dag_status']

