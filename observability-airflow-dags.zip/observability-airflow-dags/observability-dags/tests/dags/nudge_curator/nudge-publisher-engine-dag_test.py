import pytest

from airflow.models import DagBag


@pytest.fixture()
def dagbag():
    return DagBag(include_examples=False)
def test_dag_loaded(dagbag):
     dag = dagbag.dags["nudge_publisher_engine"]
     assert dagbag.import_errors == {}
     assert dag is not None

def test_number_of_tasks(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_publisher_engine")
     assert len(dag.tasks) == 3

def test_task_name_seq(dagbag) :
     dag = dagbag.get_dag(dag_id="nudge_publisher_engine")
     tasks = dag.tasks
     task_ids = list(map(lambda task: task.task_id, tasks))

     assert task_ids == ['nudge_publisher_etl','send_email', 'dag_status']

def test_dependencies_of_etl_task(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_publisher_engine")
     task = dag.get_task('nudge_publisher_etl')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert upstream_task_ids == []
     assert sorted(downstream_task_ids) == ['send_email']

def test_dependencies_of_send_email_task(dagbag):
     dag = dagbag.get_dag(dag_id="nudge_publisher_engine")
     task = dag.get_task('send_email')
     upstream_task_ids = list(map(lambda task: task.task_id, task.upstream_list))
     downstream_task_ids = list(map(lambda task: task.task_id, task.downstream_list))

     assert upstream_task_ids == ['nudge_publisher_etl']
     assert sorted(downstream_task_ids) == ['dag_status']

