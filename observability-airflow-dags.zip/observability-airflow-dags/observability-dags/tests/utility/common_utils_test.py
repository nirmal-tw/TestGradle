from airflow.operators.python import PythonOperator

from utility.common_utils import read_value_from_properties, get_airflow_variable, get_variable_dictionary_for_environment, \
                                get_variable_dictionary, on_job_failure_callback, on_job_success_callback, \
                                enviornment_based_property_file_name, load_job_prop, \
                                load_environment_job_prop

from airflow.models import DagRun
import datetime
from airflow.models import DagBag
from airflow.models.taskinstance import TaskInstance
from utility.dag_constants import ACCURACY_PROPS_PATH, EVENT_TRANSFORMER_PROPS_PATH, EMR_RELEASE_LABEL, NUDGE_VIRTUAL_CLUSTER_ID, JOB_ROLE_ARN
import os,re


def test_read_value_from_properties():
    dict = {'key1': 'value1'}
    actualResult = read_value_from_properties(dict, 'key1')
    assert actualResult == 'value1'


def test_get_airflow_variable(mocker):
    mocker.patch.dict('os.environ', AIRFLOW_VAR_MY_VARIABLE="myvalue")
    assert "myvalue" == get_airflow_variable("my_variable")


def test_get_variable_dictionary(mocker):
    mocker.patch.dict('os.environ', AIRFLOW_VAR_NUDGE_ENGINE_VIRTUAL_CLUSTER_ID="AIRFLOW_VAR_NUDGE_ENGINE_VIRTUAL_CLUSTER_ID")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_TRANSFORMER_ENGINE_VIRTUAL_CLUSTER_ID="AIRFLOW_VAR_TRANSFORMER_ENGINE_VIRTUAL_CLUSTER_ID")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_EKS_SPARK_JOB_EXECUTION_ROLE="AIRFLOW_VAR_EKS_SPARK_JOB_EXECUTION_ROLE")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_EMR_RELEASE_LABEL="AIRFLOW_VAR_EMR_RELEASE_LABEL")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_OBSERVABILITY_S3_BUCKET="AIRFLOW_VAR_OBSERVABILITY_S3_BUCKET")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_PROPERTIES_PATH_FILE_SYSTEM="AIRFLOW_VAR_PROPERTIES_PATH_FILE_SYSTEM")
    dict = get_variable_dictionary()

    mockedDict = {}
    mockPattern = re.compile(r'AIRFLOW_VAR_\w+')
    for key,value in os.environ.items():
        if mockPattern.match(key):
            mockedDict[key]=value

    assert get_airflow_variable("nudge_engine_virtual_cluster_id") == "AIRFLOW_VAR_NUDGE_ENGINE_VIRTUAL_CLUSTER_ID"
    assert get_airflow_variable("transformer_engine_virtual_cluster_id") == "AIRFLOW_VAR_TRANSFORMER_ENGINE_VIRTUAL_CLUSTER_ID"
    assert get_airflow_variable("eks_spark_job_execution_role") == "AIRFLOW_VAR_EKS_SPARK_JOB_EXECUTION_ROLE"
    assert get_airflow_variable("emr_release_label") == "AIRFLOW_VAR_EMR_RELEASE_LABEL"
    assert get_airflow_variable("observability_s3_bucket") == "AIRFLOW_VAR_OBSERVABILITY_S3_BUCKET"
    assert get_airflow_variable("properties_path_file_system") == "AIRFLOW_VAR_PROPERTIES_PATH_FILE_SYSTEM"
    # assert len(dict) == 8
    assert len(dict) == len(mockedDict)


def test_get_variable_dictionary_for_environment(mocker):
    mocker.patch.dict('os.environ', AIRFLOW_VAR_ENVIRONMENT="test")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_BASE_PATH="/test_path")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_SERVICE_USER="test_user")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_HIVE_METASTORE="localhost")

    dict = get_variable_dictionary_for_environment()

    assert dict["environment"] == "test"
    assert dict["base_path"] == "/test_path"
    assert dict["service_user"] == "test_user"
    assert dict["hive_metastore"] == "localhost"
    assert len(dict) == 4


def call_python():
    print("Call python")


#@pytest.mark.skip(reason="no way of currently testing this")
def test_on_job_failure_callback():
    dagbag = DagBag()
    dag = dagbag.get_dag(dag_id="observability_event_transformer")

    op = PythonOperator(
        task_id='test',
        python_callable=call_python,
        dag=dag
    )

    execution_date = datetime.datetime.now()

    ti = TaskInstance(task=op, execution_date=execution_date)
    context = ti.get_template_context()
    context['exception'] = ZeroDivisionError("Zero division error.")
    exception_msg = on_job_failure_callback(context)
    assert exception_msg == "ZeroDivisionError: Zero division error."


#@pytest.mark.skip(reason="no way of currently testing this")
def test_on_job_success_callback():
    dagbag = DagBag()
    dag = dagbag.get_dag(dag_id="observability_event_transformer")

    op = PythonOperator(
        task_id='test',
        python_callable=call_python,
        dag=dag
    )

    execution_date = datetime.datetime.now()

    ti = TaskInstance(task=op, execution_date=execution_date)
    context = ti.get_template_context()
    dagrun = DagRun(dag_id="observability_event_transformer")
    dagrun.task_instances = ti
    context['dag_run'] = dagrun
    exception_msg = on_job_success_callback(context)
    assert exception_msg == "Inside job success.These task instances succeeded : []"


def test_load_job_prop(mocker):
    base_path = "/observability-dags/tests/"

    mocker.patch.dict('os.environ', AIRFLOW_VAR_PROPERTIES_PATH_FILE_SYSTEM="local")
    mocker.patch.dict('os.environ',
                      AIRFLOW_VAR_EVENT_TRANSFORMER_PROPS_PATH="/resources/event/job.properties")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_ENVIRONMENT="test")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_BASE_PATH=base_path)
    mocker.patch.dict('os.environ', AIRFLOW_VAR_SERVICE_USER="test_user")

    variable_dict, env_var_dict, job_dict, spark_args_dict, spark_conf_dict, monitor_conf_dict = load_job_prop(
        EVENT_TRANSFORMER_PROPS_PATH)

    assert spark_args_dict["env"] == "test"


def test_enviornment_based_property_file_name():
    assert enviornment_based_property_file_name("resources/event/job.properties",
                                                "test") == "resources/event/job.test.properties"


def test_load_environment_job_prop(mocker):
    base_path = "/observability-dags/tests/"

    mocker.patch.dict('os.environ', AIRFLOW_VAR_PROPERTIES_PATH_FILE_SYSTEM="local")
    mocker.patch.dict('os.environ',
                      AIRFLOW_VAR_ACCURACY_PROPS_PATH= "/resources/accuracy/job.properties")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_ENVIRONMENT="test")
    mocker.patch.dict('os.environ', AIRFLOW_VAR_BASE_PATH=base_path)
    mocker.patch.dict('os.environ', AIRFLOW_VAR_SERVICE_USER="test_user")

    variable_dict = get_variable_dictionary()
    env_dict = get_variable_dictionary_for_environment()

    configs = load_environment_job_prop(variable_dict, env_dict,ACCURACY_PROPS_PATH, "test")
    assert configs.sections() == ['spark-conf-default', 'spark-conf-home', 'spark-conf-credit_card']

