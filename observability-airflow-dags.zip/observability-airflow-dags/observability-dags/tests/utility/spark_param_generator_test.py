import pytest as pytest
from utility.spark_param_generator import generate_spark_entry_args, generate_spark_submit_params, \
    generate_job_driver_args, generate_monitoring_args, get_product_wise_args
from utility.common_utils import load_environment_job_prop, get_variable_dictionary, \
    get_variable_dictionary_for_environment
from utility.dag_constants import NUDGE_CURATOR_ENGINE_PROPS_PATH
from utility.dag_constants import PROPERTIES_PATH_FILE_SYSTEM


def test_generate_spark_entry_args():
    spark_entry_point_arg_dict = {'env': 'sit', 'source': 'application', 'dbName': 'default'}
    expected_output = ['env=sit', 'source=application', 'dbName=default']
    assert generate_spark_entry_args(spark_entry_point_arg_dict) == expected_output


def test_generate_spark_submit_params():
    spark_conf_dict = {'partitionMode': 'dynamic', 'interval': '1h'}
    job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}

    expected_output = " --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf partitionMode=dynamic --conf interval=1h"
    assert generate_spark_submit_params(spark_conf_dict, job_dict) == expected_output


def test_generate_job_driver_args():
    spark_entry_point_arg_dict = {'env': 'sit', 'source': 'application', 'dbName': 'default'}
    spark_conf_dict = {'partitionMode': 'dynamic', 'interval': '1h'}
    job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}

    expected_output = {'sparkSubmitJobDriver': {'entryPoint': 'job.jar',
                                                'entryPointArguments': ['env=sit', 'source=application',
                                                                        'dbName=default',
                                                                        'jobId={{ dag.dag_id }}-{{ run_id }}'],
                                                'sparkSubmitParameters': ' --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf partitionMode=dynamic --conf interval=1h'}}

    assert generate_job_driver_args(spark_entry_point_arg_dict, spark_conf_dict, job_dict) == expected_output


def test_generate_monitoring_args_isEnabled_True_and_when_both_s3_cloudwatch_enabled():
    monitor_conf_dict = {'isEnabled': 'True', 'cloudWatchEnabled': 'True', 'logGroupName': '/emr-on-eks/jobs',
                         'logStreamNamePrefix': 'event-transformer', 's3Enabled': 'True',
                         'logUri': 's3://eks-spike/logs/'}
    assert generate_monitoring_args(monitor_conf_dict) == {'monitoringConfiguration': {
        'cloudWatchMonitoringConfiguration': {'logGroupName': '/emr-on-eks/jobs',
                                              'logStreamNamePrefix': '/emr-on-eks/jobs'},
        's3MonitoringConfiguration': {'logUri': 's3://eks-spike/logs/'}}}

def test_generate_monitoring_args_isEnabled_True_and_when_s3Enabled_is_False():
    monitor_conf_dict = {'isEnabled': 'True', 'cloudWatchEnabled': 'True',
                         'logGroupName': '/emr-on-eks/jobs','logStreamNamePrefix': 'event-transformer',
                         's3Enabled': 'False','logUri': 's3://eks-spike/logs/'}

    assert generate_monitoring_args(monitor_conf_dict) == {'monitoringConfiguration': {
        'cloudWatchMonitoringConfiguration': {'logGroupName': '/emr-on-eks/jobs',
                                              'logStreamNamePrefix': '/emr-on-eks/jobs'}
        }}

def test_generate_monitoring_args_isEnabled_True_and_when_cloudWatch_is_False():
    monitor_conf_dict = {'isEnabled': 'True', 'cloudWatchEnabled': 'False',
                         'logGroupName': '/emr-on-eks/jobs','logStreamNamePrefix': 'event-transformer',
                         's3Enabled': 'True','logUri': 's3://eks-spike/logs/'}

    assert generate_monitoring_args(monitor_conf_dict) == {'monitoringConfiguration': {
        's3MonitoringConfiguration': {'logUri': 's3://eks-spike/logs/'}}}

def test_generate_monitoring_args_isEnabled_True_and_when_both_s3_and_cloudwatch_disabled():
    monitor_conf_dict = {'isEnabled': 'True', 'cloudWatchEnabled': 'False',
                         'logGroupName': '/emr-on-eks/jobs','logStreamNamePrefix': 'event-transformer',
                         's3Enabled': 'False','logUri': 's3://eks-spike/logs/'}

    with pytest.raises(ValueError):
        generate_monitoring_args(monitor_conf_dict)

def test_generate_monitoring_args_isEnabled_False_and_when_cloudWatch_is_False_and_s3_is_True():
    monitor_conf_dict = {'isEnabled': 'False', 'cloudWatchEnabled': 'False',
                         'logGroupName': '/emr-on-eks/jobs','logStreamNamePrefix': 'event-transformer',
                         's3Enabled': 'True','logUri': 's3://eks-spike/logs/'}

    assert generate_monitoring_args(monitor_conf_dict) == {}


def test_get_product_wise_args_with_empty_product_list():
    product = ""
    spark_entry_point_arg_dict = {'env': 'test', 'jobId': '{{ dag.dag_id }}-{{ run_id }}', 'jobName': 'nudge-curator',
                                  'cdmDataPath': '/observability-dags/tests//user/test_user/observability.db/mlp/events/cdm',
                                  'eventStatusMappingPath': '/observability-dags/tests//user/test_user/observability.db/mlp/events/event_meta_info/application_status_event_mapping',
                                  'statusFilePath': '/observability-dags/tests//user/test_user/observability.db/mlp/job_status/nudge',
                                  'dbName': 'default', 'repairSchemaTables': 'repairSchemaTables',
                                  'emailPropertiesFile': '/observability-dags/tests//resources/alerts/notifier.properties',
                                  'credsPropsFileName': 'creds.properties', 'baseDir': '/etc/spark/conf/observability/'}
    #
    spark_conf_dict = {'environment': 'test', 'base_path': '/observability-dags/tests/', 'service_user': 'test_user',
                       'hive_metastore': 'localhost', 'spark.sql.sources.partitionOverwriteMode': 'dynamic',
                       'spark.dynamicAllocation.minExecutors': '1', 'spark.sql.parquet.mergeSchema': 'true',
                       'spark.driver.memoryOverhead': '512m', 'spark.executor.memory': '2g',
                       'spark.driver.memory': '1g', 'spark.executor.memoryOverhead': '1g',
                       'spark.sql.session.timeZone': 'Asia/Kolkata', 'spark.sql.shuffle.partitions': '10',
                       'spark.kubernetes.driver.podTemplateFile': '/observability-dags/tests//resources/nudge-curator/driver-pod-template.yaml',
                       'spark.kubernetes.executor.podTemplateFile': '/observability-dags/tests//resources/nudge-curator/executor-pod-template.yaml'}
    job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}

    base_path = "/observability-dags/tests/resources/transformation-engine/reprocessing"

    env_dict = {'environment': 'test', 'base_path': '/observability-dags/tests/', 'service_user': 'test_user',
                'hive_metastore': 'localhost'}

    variable_dict = {'nudge_engine_virtual_cluster_id': '#', 'transformer_engine_virtual_cluster_id': '#',
                     'eks_spark_job_execution_role': '#', 'emr_release_label': 'emr-6.3.0-20210429',
                     'observability_s3_bucket': '#', 'properties_path_file_system': 'local'}
    environment_configs = load_environment_job_prop(variable_dict,
                                                    env_dict,
                                                    NUDGE_CURATOR_ENGINE_PROPS_PATH,
                                                    "test")

    actual_job_driver = get_product_wise_args(product, spark_entry_point_arg_dict, spark_conf_dict,
                                              job_dict, environment_configs)

    expected_job_driver = {'sparkSubmitJobDriver':
                                 {'entryPoint': 'job.jar',
                                  'entryPointArguments': ['env=test', 'jobId={{ dag.dag_id }}-{{ run_id }}','jobName=nudge-curator', 'cdmDataPath=/observability-dags/tests//user/test_user/observability.db/mlp/events/cdm','eventStatusMappingPath=/observability-dags/tests//user/test_user/observability.db/mlp/events/event_meta_info/application_status_event_mapping','statusFilePath=/observability-dags/tests//user/test_user/observability.db/mlp/job_status/nudge', 'dbName=default', 'repairSchemaTables=repairSchemaTables','emailPropertiesFile=/observability-dags/tests//resources/alerts/notifier.properties', 'credsPropsFileName=creds.properties','baseDir=/etc/spark/conf/observability/', 'productType='],
                                  'sparkSubmitParameters': ' --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf environment=test --conf base_path=/observability-dags/tests/ --conf service_user=test_user --conf hive_metastore=localhost --conf spark.sql.sources.partitionOverwriteMode=dynamic --conf spark.dynamicAllocation.minExecutors=1 --conf spark.sql.parquet.mergeSchema=true --conf spark.driver.memoryOverhead=512m --conf spark.executor.memory=800m --conf spark.driver.memory=2g --conf spark.executor.memoryOverhead=1g --conf spark.sql.session.timeZone=Asia/Kolkata --conf spark.sql.shuffle.partitions=10 --conf spark.kubernetes.driver.podTemplateFile=/observability-dags/tests//resources/nudge-curator/driver-pod-template.yaml --conf spark.kubernetes.executor.podTemplateFile=/observability-dags/tests//resources/nudge-curator/executor-pod-template.yaml'
                                  }
                           }

    assert actual_job_driver == expected_job_driver

def test_get_product_wise_args_with_personal_in_product_list():
    product = "personal"
    spark_entry_point_arg_dict = {'env': 'test', 'jobId': '{{ dag.dag_id }}-{{ run_id }}', 'jobName': 'nudge-curator',
                                  'cdmDataPath': '/observability-dags/tests//user/test_user/observability.db/mlp/events/cdm',
                                  'eventStatusMappingPath': '/observability-dags/tests//user/test_user/observability.db/mlp/events/event_meta_info/application_status_event_mapping',
                                  'statusFilePath': '/observability-dags/tests//user/test_user/observability.db/mlp/job_status/nudge',
                                  'dbName': 'default', 'repairSchemaTables': 'repairSchemaTables',
                                  'emailPropertiesFile': '/observability-dags/tests//resources/alerts/notifier.properties',
                                  'credsPropsFileName': 'creds.properties', 'baseDir': '/etc/spark/conf/observability/'}
    #
    spark_conf_dict = {'environment': 'test', 'base_path': '/observability-dags/tests/', 'service_user': 'test_user',
                       'hive_metastore': 'localhost', 'spark.sql.sources.partitionOverwriteMode': 'dynamic',
                       'spark.dynamicAllocation.minExecutors': '1', 'spark.sql.parquet.mergeSchema': 'true',
                       'spark.driver.memoryOverhead': '512m', 'spark.executor.memory': '2g',
                       'spark.driver.memory': '1g', 'spark.executor.memoryOverhead': '1g',
                       'spark.sql.session.timeZone': 'Asia/Kolkata', 'spark.sql.shuffle.partitions': '10',
                       'spark.kubernetes.driver.podTemplateFile': '/observability-dags/tests//resources/nudge-curator/driver-pod-template.yaml',
                       'spark.kubernetes.executor.podTemplateFile': '/observability-dags/tests//resources/nudge-curator/executor-pod-template.yaml'}
    job_dict = {'className': 'com.axis.observability.transformation.TransformationDriver', 'jars': 'lib/*.jar',
                'deployMode': 'cluster', 'entryPoint': 'job.jar',
                'jobSchedule': '15 8 * * *'}

    base_path = "/observability-dags/tests/resources/transformation-engine/reprocessing"

    env_dict = {'environment': 'test', 'base_path': '/observability-dags/tests/', 'service_user': 'test_user',
                'hive_metastore': 'localhost'}

    variable_dict = {'nudge_engine_virtual_cluster_id': '#', 'transformer_engine_virtual_cluster_id': '#',
                     'eks_spark_job_execution_role': '#', 'emr_release_label': 'emr-6.3.0-20210429',
                     'observability_s3_bucket': '#', 'properties_path_file_system': 'local'}
    environment_configs = load_environment_job_prop(variable_dict,
                                                    env_dict,
                                                    NUDGE_CURATOR_ENGINE_PROPS_PATH,
                                                    "test")

    actual_job_driver = get_product_wise_args(product, spark_entry_point_arg_dict, spark_conf_dict,
                                              job_dict, environment_configs)

    expected_job_driver = {'sparkSubmitJobDriver':
                                 {'entryPoint': 'job.jar',
                                  'entryPointArguments': ['env=test', 'jobId={{ dag.dag_id }}-{{ run_id }}','jobName=nudge-curator', 'cdmDataPath=/observability-dags/tests//user/test_user/observability.db/mlp/events/cdm','eventStatusMappingPath=/observability-dags/tests//user/test_user/observability.db/mlp/events/event_meta_info/application_status_event_mapping','statusFilePath=/observability-dags/tests//user/test_user/observability.db/mlp/job_status/nudge', 'dbName=default', 'repairSchemaTables=repairSchemaTables','emailPropertiesFile=/observability-dags/tests//resources/alerts/notifier.properties', 'credsPropsFileName=creds.properties','baseDir=/etc/spark/conf/observability/', 'productType=personal'],
                                  'sparkSubmitParameters': ' --class com.axis.observability.transformation.TransformationDriver --deploy-mode cluster --jars lib/*.jar --conf environment=test --conf base_path=/observability-dags/tests/ --conf service_user=test_user --conf hive_metastore=localhost --conf spark.sql.sources.partitionOverwriteMode=dynamic --conf spark.dynamicAllocation.minExecutors=100 --conf spark.sql.parquet.mergeSchema=true --conf spark.driver.memoryOverhead=100m --conf spark.executor.memory=100m --conf spark.driver.memory=100g --conf spark.executor.memoryOverhead=100g --conf spark.sql.session.timeZone=Asia/Kolkata --conf spark.sql.shuffle.partitions=10 --conf spark.kubernetes.driver.podTemplateFile=/observability-dags/tests//resources/nudge-curator/driver-pod-template.yaml --conf spark.kubernetes.executor.podTemplateFile=/observability-dags/tests//resources/nudge-curator/executor-pod-template.yaml'
                                  }
                           }
    assert actual_job_driver == expected_job_driver