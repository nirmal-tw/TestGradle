import json

from utility.file_utils import read_configs, read_from_local, read_from_s3
from utility.dag_constants import PROPERTIES_PATH_FILE_SYSTEM
import pytest


def test_read_configs():
    variable_dict = {PROPERTIES_PATH_FILE_SYSTEM: "local"}

    base_path = "/observability-dags/tests"
    env_dict = {"enviornment": "test", "base_path": base_path, "service_user": "sit_hadoop"}
    conf_file_name = "/resources/transformation-engine/event/job.properties"
    config = read_configs(conf_file_name, variable_dict, env_dict)
    sections = config.sections()
    assert len(sections) == 4
    assert dict(config.items("job-params"))['className'] == "com.axis.observability.transformation.TransformationDriver"
    assert dict(config.items("job-params"))['jobSchedule'] == "15 8 * * *"


def test_read_conf_from_local():
    base_path = "/observability-dags/tests"
    conf_file_name = "/resources/transformation-engine/event/job.properties"
    env_dict = {"enviornment": "test", "base_path": base_path, "service_user": "sit_hadoop"}
    config = read_from_local(conf_file_name, env_dict)
    sections = config.sections()

    assert len(sections) == 4
    assert dict(config.items("job-params"))['className'] == "com.axis.observability.transformation.TransformationDriver"
    assert dict(config.items("job-params"))['jobSchedule'] == "15 8 * * *"


@pytest.mark.skip(reason="Can test only with s3 enabled")
def test_read_conf_from_s3():
    conf_file_name = "resources/transformation-engine/event/job.properties"
    base_path = "/observability-dags/tests"
    f = open(base_path+"/resources/variables.json")
    variable_dict = json.loads(f.read())
    env_dict = {"enviornment": "test", "base_path": "s3://eks-spike", "service_user": "sit_hadoop"}
    config = read_from_s3(conf_file_name, env_dict)
    sections = config.sections()
    assert len(sections) == 4
    assert dict(config.items("job-params"))['className'] == "com.axis.observability.transformation.TransformationDriver"
    assert dict(config.items("job-params"))['jobSchedule'] == "15 8 * * *"

