#!/bin/bash
set -e
env=${ENV}
s3Bucket=${S3_BUCKET}
serviceUser=${SERVICE_USER}
airflow_environment_name=${AIRFLOW_ENVIRONMENT_NAME}
eks_spark_job_execution_role=${EKS_SPARK_JOB_EXECUTION_ROLE}
hive_metastore=${HIVE_METASTORE}
nudge_engine_virtual_cluster_id=${NUDGE_ENGINE_VIRTUAL_CLUSTER_ID}
transformer_engine_virtual_cluster_id=${TRANSFORMER_ENGINE_VIRTUAL_CLUSTER_ID}
emr_release_label="emr-6.3.0-20210429"
base_path="s3a://${s3Bucket}/user/${serviceUser}"

echo $env
echo $s3Bucket
echo $serviceUser
echo $airflow_environment_name
echo $eks_spark_job_execution_role
echo $hive_metastore
echo $nudge_engine_virtual_cluster_id
echo $transformer_engine_virtual_cluster_id

CLI_JSON=$(aws mwaa --region ap-south-1 create-cli-token --name ${airflow_environment_name})
CLI_TOKEN=$(echo $CLI_JSON | jq -r '.CliToken')
WEB_SERVER_HOSTNAME=$(echo $CLI_JSON | jq -r '.WebServerHostname')

curl_post_req_set_variable() {
  key=$1
  value=$2
  CLI_RESULTS=$(curl --request POST "https://$WEB_SERVER_HOSTNAME/aws_mwaa/cli"  --header "Authorization: Bearer $CLI_TOKEN"  --header "Content-Type: text/plain" --data "variables set ${key} ${value}")
  echo "Output:" && echo $CLI_RESULTS | jq -r '.stdout' | base64 --decode
  echo "Errors:" && echo $CLI_RESULTS | jq -r '.stderr' | base64 --decode
}

curl_post_req_get_variable() {
  key=$1
  CLI_RESULTS=$(curl --request POST "https://$WEB_SERVER_HOSTNAME/aws_mwaa/cli"  --header "Authorization: Bearer $CLI_TOKEN"  --header "Content-Type: text/plain" --data "variables get ${key}")
  echo "Output:" && echo $CLI_RESULTS | jq -r '.stdout' | base64 --decode
  echo "Errors:" && echo $CLI_RESULTS | jq -r '.stderr' | base64 --decode
}

curl_post_req_set_variable properties_path_file_system "s3"
curl_post_req_set_variable emr_release_label ${emr_release_label}
curl_post_req_set_variable base_path ${base_path}
curl_post_req_set_variable eks_spark_job_execution_role ${eks_spark_job_execution_role}
curl_post_req_set_variable environment ${env}
curl_post_req_set_variable service_user ${serviceUser}
curl_post_req_set_variable hive_metastore ${hive_metastore}
curl_post_req_set_variable observability_s3_bucket ${s3Bucket}
curl_post_req_set_variable nudge_engine_virtual_cluster_id ${nudge_engine_virtual_cluster_id}
curl_post_req_set_variable transformer_engine_virtual_cluster_id ${transformer_engine_virtual_cluster_id}

# use curl_post_req_get_variable method to get the airflow variables. i.e "curl_post_req_get_variable nudge_engine_virtual_cluster_id"