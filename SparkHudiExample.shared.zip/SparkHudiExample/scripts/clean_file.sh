file_name=fixed_width_sample.txt

sed -n '1p' $file_name > header_$file_name

sed -n '$p' $file_name > footer_$file_name
sed '1d;$d' $file_name > ${file_name}_temp
awk -v OFS=, '{ print substr($0, 1, 1), substr($0, 2, 10), substr($0, 12, 4), substr($0, 16, 2), substr($0, 18, 2) }' ${file_name}_temp > transformed_${file_name}
rm ${file_name}_temp
