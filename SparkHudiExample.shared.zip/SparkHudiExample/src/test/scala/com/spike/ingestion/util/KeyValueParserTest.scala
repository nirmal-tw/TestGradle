package com.spike.ingestion.util

import com.spike.ingestion.util.Constants.EMPTY
import org.scalatest.{Matchers, WordSpec}

class KeyValueParserTest extends WordSpec with Matchers {

  "getValue" should {
    "parse args as key value pair" in {
      val keyValueParser = new KeyValueParser(Array("testKey1=testValue1"))
      val actual = keyValueParser.getValue("testKey1")
      "testValue1" should equal(actual)
    }

    "skip if key is empty" in {
      val keyValueParser = new KeyValueParser(Array("=testValue1"))
      val thrown = intercept[NoSuchElementException] {
        keyValueParser.getValue("")
      }
      assert(thrown.getMessage.contains("key not found"))
    }

    "skip if format is invalid" in {
      val keyValueParser = new KeyValueParser(Array("testKey1testValue1"))
      val thrown = intercept[NoSuchElementException] {
        keyValueParser.getValue("testKey1")
      }
      assert(thrown.getMessage.contains("key not found"))
    }

    "trim extra spaces from key and value" in {
      val keyValueParser = new KeyValueParser(Array(" testKey1 = testValue1 "))
      val actual = keyValueParser.getValue("testKey1")
      "testValue1" should equal(actual)
    }
  }

  "getOptionalValue" should {
    "return value for given key" in {
      val keyValueParser = new KeyValueParser(Array("testKey1=testValue1"))
      val actual = keyValueParser.getOptionalValue("testKey1")
      actual should equal(Some("testValue1"))
    }

    "return None when given key is not present" in {
      val keyValueParser = new KeyValueParser(Array("testKey1=testValue1"))
      keyValueParser.getOptionalValue("missingKey") should equal(None)
    }

    "return None if format is invalid" in {
      val keyValueParser = new KeyValueParser(Array("testKey1testValue1"))
      keyValueParser.getOptionalValue("testKey1") should equal(None)
    }

    "trim extra spaces from key and value" in {
      val keyValueParser = new KeyValueParser(Array(" testKey1 = testValue1 "))
      val actual = keyValueParser.getOptionalValue("testKey1")
      actual should equal(Some("testValue1"))
    }
  }

  "getOptionalStringValue" should {
    "return value for given key" in {
      val keyValueParser = new KeyValueParser(Array("testKey1=testValue1"))
      val actual = keyValueParser.getOptionalStringValue("testKey1")
      actual should equal("testValue1")
    }

    "return EMPTY when given key is not present" in {
      val keyValueParser = new KeyValueParser(Array("testKey1=testValue1"))
      keyValueParser.getOptionalStringValue("missingKey") should equal(EMPTY)
    }

    "return None if format is invalid" in {
      val keyValueParser = new KeyValueParser(Array("testKey1testValue1"))
      keyValueParser.getOptionalStringValue("testKey1") should equal(EMPTY)
    }

    "trim extra spaces from key and value" in {
      val keyValueParser = new KeyValueParser(Array(" testKey1 = testValue1 "))
      val actual = keyValueParser.getOptionalStringValue("testKey1")
      actual should equal("testValue1")
    }
  }
}
