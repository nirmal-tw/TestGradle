package com.spike.ingestion.helpers

import com.holdenkarau.spark.testing.DataFrameSuiteBase
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.WordSpec

trait SparkTestBase extends WordSpec with DataFrameSuiteBase {

  val customConf: SparkConf = new SparkConf()
    .set("spark.sql.session.timeZone", "Asia/Kolkata")
    .set("spark.sql.shuffle.partitions", "1")

  override implicit lazy val spark: SparkSession = SparkSession
    .builder()
    .master("local")
    .config(customConf)
    .appName("spark test example")
    .getOrCreate()

  def setNullableStateOfColumn(df: DataFrame, columnName: String, nullable: Boolean): DataFrame = {
    val schema = df.schema
    val newSchema = StructType(schema.map {
      case StructField(cn, dt, _, m) if cn.equals(columnName) => StructField(cn, dt, nullable = nullable, m)
      case y: StructField => y
    })
    // apply new schema
    df.sqlContext.createDataFrame(df.rdd, newSchema)
  }

  def setNullableStateOfColumn(df: DataFrame, nullable: Boolean, columnName: String*): DataFrame = {
    val schema = df.schema
    val newSchema = StructType(schema.map {
      case StructField(cn, dt, _, m) if columnName.contains(cn) => StructField(cn, dt, nullable = nullable, m)
      case y: StructField => y
    })
    // apply new schema
    df.sqlContext.createDataFrame(df.rdd, newSchema)
  }

  def sortDataframe(df: DataFrame): DataFrame = {
    val colNames = df.columns.sorted
    val cols     = colNames.map(col)
    df.sort(cols: _*)
  }

  val rawDataSchema = StructType(
    Array(
      StructField("topic", StringType, true), StructField("value", StringType, true), StructField("unique_identifier", StringType, true),
      StructField("event_time", TimestampType, true), StructField("created_time", StringType, true), StructField("timestamp", LongType, true)
    )
  )

  def assertEqualsIgnoringSchema(expected: DataFrame, actual: DataFrame): Unit = {
    assertDataFrameEquals(
      setNullableStateOfColumn(expected, true, expected.columns :_*),
      setNullableStateOfColumn(actual, true, actual.columns :_*)
    )
  }
}
