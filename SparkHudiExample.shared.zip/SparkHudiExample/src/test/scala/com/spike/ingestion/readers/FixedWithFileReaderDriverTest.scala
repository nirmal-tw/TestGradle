package com.spike.ingestion.readers

import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{DateTime, DateTimeUtils}
import org.scalamock.scalatest.MockFactory
import org.scalatest.Matchers

import java.io.File
import com.spike.ingestion.helpers.SparkTestBase
import com.spike.ingestion.schema.JSONSchema
import com.spike.ingestion.util.ArgumentKeys.{FIXED_WIDTH_FILE_LOCATION, FIXED_WIDTH_FILE_SCHEMA_LOCATION, JOB_ID, JOB_NAME, SOURCE}
import com.spike.ingestion.util.KeyValueParser

class FixedWithFileReaderDriverTest extends SparkTestBase with MockFactory with Matchers {
   import spark.implicits._
  "fixedWidthReader" should {
    "Should read the fixed width file as per supplied schema" in {
      FileUtils.deleteQuietly(new File("src/test/resources/temp"))
      val keyValueParser = mock[KeyValueParser]
      val ioHandler = mock[IOHandler]
      val config= mock[FixedWidthFileConfig]
      val fixedWidthToDataframeTransformer = mock[FixedWidthToDataframeTransformer]
      (keyValueParser.getValue _).expects(FIXED_WIDTH_FILE_SCHEMA_LOCATION).returning("schema_location")
      (keyValueParser.getValue _).expects(FIXED_WIDTH_FILE_LOCATION).returning("file_location")
      val df = Seq(("id", 0,1)).toDF("Column","From","To").as[JSONSchema]
      val schemaArr = df.collect()
      val textDf = Seq(("testdata")).toDF()
      val transformedDf = Seq(("t")).toDF("id")
      val map = Map("data" ->transformedDf)

      (ioHandler.getJSONSchema _).expects("schema_location").returning(schemaArr)
      (ioHandler.readFixedWidthTextFile _).expects("file_location").returning(textDf)
      (fixedWidthToDataframeTransformer.convertFixedWitdhDFToColumnDF( _:DataFrame,_:Array[JSONSchema],_:FixedWidthFileConfig)(_: SparkSession))
        .expects(textDf,schemaArr,config,spark)
        .returning(map)

      val transformationDriver = new FixedWidthFileReaderDriver(ioHandler,keyValueParser,fixedWidthToDataframeTransformer)
      val actualDf = transformationDriver.readFixedWidthAndTransform(spark)
      assertDataFrameEquals(actualDf,transformedDf)
    }
  }
}
