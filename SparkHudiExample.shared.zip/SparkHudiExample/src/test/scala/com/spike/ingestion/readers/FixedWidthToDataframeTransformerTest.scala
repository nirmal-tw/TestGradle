package com.spike.ingestion.readers

import com.spike.ingestion.helpers.SparkTestBase
import com.spike.ingestion.schema.JSONSchema
import org.scalamock.scalatest.MockFactory
import org.scalatest.{FunSuite, Matchers}

class FixedWidthToDataframeTransformerTest extends SparkTestBase with MockFactory with Matchers {

  "transformer" should {
    "Convert fixed width single column to given schema" in {
      import spark.implicits._
      val df = Seq(("id", 0,2),("name",2,6),("salary",6,11)).toDF("Column","From","To").as[JSONSchema]
      val schemaArr = df.collect()
      val textDf = Seq(("11test25000"),("12joa 2600 ")).toDF()
      val expectedTransformedDf = Seq(("11","test","25000"),("12","joa","2600")).toDF("id", "name", "salary")
      val config = FixedWidthFileConfig(FixedFileInput("","", FixedFileHeader(false,""),FixedFileFooter(false,"")))

      val fixedWidthToDataframeTransformer = new FixedWidthToDataframeTransformer
      val actualTransformedDf = fixedWidthToDataframeTransformer
        .convertFixedWitdhDFToColumnDF(textDf, schemaArr,config).get("data").get
      actualTransformedDf.show()
      assertDataFrameEquals(actualTransformedDf,expectedTransformedDf)
    }
  }
}
