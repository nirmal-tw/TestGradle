package com.spike.ingestion.helpers

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}

object DataFrameImplicits {

  implicit class RichDataFrame(val d: DataFrame) {
    def withSchema(schema: StructType)(implicit sparkSession: SparkSession): DataFrame = {
      sparkSession.createDataFrame(d.rdd, schema)
    }
  }
}
