package com.spike.ingestion.readers

import com.spike.ingestion.helpers.SparkITestBase
import com.spike.ingestion.util.{IOUtil, KeyValueParser}
import org.apache.commons.io.FileUtils
import org.joda.time.DateTimeUtils
import org.scalatest.MustMatchers

import java.io.File

class FixedWidthFileReaderDriverITest extends SparkITestBase with MustMatchers {

  "FixedWidthFileReader" should {
    "Should read fixed length file and convert as per given schema" in {
      DateTimeUtils.setCurrentMillisFixed(1574244322649L)
      try {
        val jobArgs: List[String] = List("env=sit","baseDir=src/it/resources/", "fixedWidthFileSchemaLocation=src/it/resources/fixed_width_file_schema.json", "fixedWidthFileLocation=src/it/resources/fixed_width_sample.txt","fixedWidthReaderConfPath=fixed_width_file_reader.conf")

        val keyValueParser = new KeyValueParser(jobArgs)
        val ioUtil =new IOUtil()
        val iOHandler = new IOHandler(spark,ioUtil)
        val fixedWidthToDataframeTransformer = new FixedWidthToDataframeTransformer

        val fixedWidthFileReaderDriver = new FixedWidthFileReaderDriver(iOHandler,keyValueParser,fixedWidthToDataframeTransformer)

        val actualDf = fixedWidthFileReaderDriver.readFixedWidthAndTransform

        val expectedOutputPath = "src/it/resources/output/"
        val expectedf= spark.read.format("csv").option("header", "true").option("sep", "|").load(s"$expectedOutputPath/expected_fixed_width_output.csv")
        assertDataFrameEquals(actualDf, expectedf)

      } finally {
        FileUtils.deleteQuietly(new File("./src/it/resources/temp"))
      }
    }
  }
}