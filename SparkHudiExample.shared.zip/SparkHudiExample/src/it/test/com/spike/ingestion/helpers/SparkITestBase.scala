package com.spike.ingestion.helpers

import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.spike.ingestion.util.{ConfigurationHelper, SparkSessionFactory}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.WordSpec

trait SparkITestBase extends WordSpec with DataFrameSuiteBase {

  val customConf: SparkConf = new SparkConf()
  val configHelper = new ConfigurationHelper("test", "src/it/resources/")

  override implicit lazy val spark: SparkSession = sparkSession

  private def sparkSession = {
    val sparkSession = new SparkSessionFactory(configHelper).getSparkSession
    sparkSession.conf.set("spark.sql.session.timeZone", "Asia/Kolkata")
    sparkSession.conf.set("spark.sql.shuffle.partitions", "1")
    sparkSession.conf.set("spark.sql.caseSensitive", "true")
    sparkSession
  }

  def setNullableStateOfColumn(df: DataFrame, nullable: Boolean, columnName: String*): DataFrame = {
    val schema = df.schema
    val newSchema = StructType(schema.map {
      case StructField(cn, dt, _, m) if columnName.contains(cn) => StructField(cn, dt, nullable = nullable, m)
      case y: StructField => y
    })
    // apply new schema
    df.sqlContext.createDataFrame(df.rdd, newSchema)
  }

  def sortDataframe(df: DataFrame): DataFrame = {
    val colNames = df.columns.sorted
    val cols     = colNames.map(col)
    df.sort(cols: _*)
  }
}
