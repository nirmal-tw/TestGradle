package com.spike.ingestion.readers

import com.spike.ingestion.models.FixedWidthFileConfig
import com.spike.ingestion.schema.JSONSchema
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.sql.functions.col

class FixedWidthToDataframeTransformer {

  def getColAtIndex(id: Int): Column = col(s"value")(id).as(s"value_${id + 1}")

  def convertFixedWitdhDFToColumnDF(sourceDf : DataFrame,schemaArr : Array[JSONSchema], fixedWidthFileConfig: FixedWidthFileConfig)(implicit sparkSession: SparkSession): Map[String, DataFrame] ={
    val columns: IndexedSeq[Column] = (0 to schemaArr.length - 1).map(getColAtIndex)
    import sparkSession.implicits._


    (fixedWidthFileConfig.input.header.isAvaiable, fixedWidthFileConfig.input.footer.isAvaiable) match {
      case (false, false) =>
       val df = sourceDf.map(l => {
          schemaArr.map(schema => l.getString(0).substring(schema.From, schema.To).trim)
        }).select(columns: _*).toDF(schemaArr.map(_.Column): _*)
        Map("data"-> df)

//      case (true,false) =>
//        sourceDf.filter(!col("value").startsWith(fixedWidthFileConfig.input.header.prefix))
//          .map(l => {
//            schemaArr.map(schema => l.getString(0).substring(schema.From, schema.To).trim)
//          }).select(columns: _*).toDF(schemaArr.map(_.Column): _*)
//
//      case (false,true) =>
//        sourceDf.filter(!col("value").startsWith(fixedWidthFileConfig.input.footer.prefix))
//          .map(l => {
//            schemaArr.map(schema => l.getString(0).substring(schema.From, schema.To).trim)
//          }).select(columns: _*).toDF(schemaArr.map(_.Column): _*)
//
      case (true,true) =>
        val df = sourceDf.filter(!col("value").startsWith(fixedWidthFileConfig.input.header.prefix))
        .filter(!col("value").startsWith(fixedWidthFileConfig.input.footer.prefix))
          .map(l => {
          schemaArr.map(schema => l.getString(0).substring(schema.From, schema.To).trim)
        }).select(columns: _*).toDF(schemaArr.map(_.Column): _*)

        val headerDf = sourceDf.filter(col("value").startsWith(fixedWidthFileConfig.input.header.prefix))
        val footerDf = sourceDf.filter(col("value").startsWith(fixedWidthFileConfig.input.footer.prefix))
        Map("data" ->df, "header"->headerDf , "footer" ->footerDf)
    }
  }
}
