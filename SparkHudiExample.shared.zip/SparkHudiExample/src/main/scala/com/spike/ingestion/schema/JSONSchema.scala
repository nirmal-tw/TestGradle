package com.spike.ingestion.schema

case class JSONSchema(Column: String, From: Int, To: Int)