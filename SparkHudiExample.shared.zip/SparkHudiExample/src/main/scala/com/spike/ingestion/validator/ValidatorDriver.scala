package com.spike.ingestion.validator

import javax.validation.ValidatorFactory

class ValidatorDriver {

def validate(): Unit ={

  val validator = ValidatorFactory.getValidator()

}

}
