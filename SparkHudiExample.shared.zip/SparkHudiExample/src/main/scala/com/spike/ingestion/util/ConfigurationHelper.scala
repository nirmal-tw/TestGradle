package com.spike.ingestion.util

import com.typesafe.config.ConfigException.Missing
import com.typesafe.config._

import java.io.File
import java.util
import java.util.Properties
import scala.collection.JavaConverters._
import com.spike.ingestion.util.Constants.{EMPTY,DEFAULT_CONFIGURATION}


class ConfigurationHelper(env: String, baseDir: String = EMPTY, argsProperties: Map[String, String] = null, fileName: String = "") {
  private val configResolutionOptions = ConfigResolveOptions.defaults().setAllowUnresolved(true)
  private val args: Config = if (argsProperties == null) {
    ConfigFactory.empty()
  } else {
    ConfigFactory.load(ConfigFactory.parseMap(argsProperties.asJava))
  }
  val config: Config = fileName match {
    case EMPTY =>
      val default = ConfigFactory.load(ConfigFactory.parseFile(new File(s"$baseDir$DEFAULT_CONFIGURATION")).resolveWith(args, configResolutionOptions), configResolutionOptions)
      val application = ConfigFactory.load(ConfigFactory.parseFile(new File(s"${baseDir}application.$env.conf")).resolveWith(args, configResolutionOptions), configResolutionOptions)
      args.withFallback(application).withFallback(default)
    case _     =>
      val fileConfig = ConfigFactory.load(ConfigFactory.parseFile(new File(s"$baseDir$fileName")).resolve())
      args.withFallback(fileConfig)
  }


  @throws(classOf[Missing])
  def getString(key: String): String = {
    config.getString(getConfig(key))
  }

  def getBoolean(key: String): Boolean = {
    config.getBoolean(getConfig(key))
  }

  def getStringList(key: String): List[String] = {
    config.getStringList(getConfig(key)).asScala.toList
  }

  def getChildrenKeys(key: String): List[String] = {
    config.getObject(key).unwrapped().keySet().asScala.toList
  }

  def getPropertiesBundle(key: String): Properties = {
    if (config.hasPath(key)) {
      val entryIt: util.Iterator[java.util.Map.Entry[String, ConfigValue]] = config.getConfig(key).entrySet().iterator()
      val connectionProps = new Properties()
      while (entryIt.hasNext) {
        val data = entryIt.next()
        connectionProps.put(data.getKey, data.getValue.render().replaceAll("\"", EMPTY))
      }
      connectionProps
    } else {
      new Properties()
    }
  }

  @throws(classOf[Missing])
  private def getConfig(key: String): String = {
    if (hasPathFor(key)) {
      s"$key"
    }
    else
      throw new Missing(key, null)
  }

  private def hasPathFor(key: String): Boolean = {
    config.hasPath(s"$key")
  }
}
