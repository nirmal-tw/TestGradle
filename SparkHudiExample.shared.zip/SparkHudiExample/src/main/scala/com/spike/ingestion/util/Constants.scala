package com.spike.ingestion.util

object Constants {
  val CSV_FORMAT = "com.databricks.spark.csv"
  val JSON_FORMAT = "json"
  val TEXT_FORMAT = "text"
  val EMPTY = ""
  val DEFAULT_CONFIGURATION = "default.conf"
  val APP_NAME = "EXPERIAN_ETL_SPIKE"
  val SPARK = "spark"
}


object ArgumentKeys {
  val JOB_ID = "jobId"
  val JOB_NAME = "jobName"
  val SOURCE = "source"
  val ENV = "env"
  val BASE_DIR = "baseDir"
  val FIXED_WIDTH_FILE_LOCATION = "fixedWidthFileLocation"
  val FIXED_WIDTH_FILE_SCHEMA_LOCATION = "fixedWidthFileSchemaLocation"
  val FIXED_WIDTH_FILE_READER_CONF_PATH = "fixedWidthReaderConfPath"
}

object ValidatorConstants {
  val RECORD_COUNT_SHOULD_MATCH_FOOTER_COUNT = "RECORD_COUNT_SHOULD_MATCH_FOOTER_COUNT"
}
