package com.spike.ingestion.util

import com.spike.ingestion.util.Constants.EMPTY

class KeyValueParser(arguments: Seq[String]) {

  private val splitIntoTwoPart = 2

  lazy val keyValueMap: Map[String, String] = arguments.map(_.split("=", splitIntoTwoPart) match {
    case Array(key, value) => key.trim -> value.trim
    case _ => "" -> ""
  }).toMap.filterKeys(_.nonEmpty)


  def getValue(key:String): String =
  {
     keyValueMap(key)
  }

  def getOptionalValue(key:String): Option[String] =
  {
    keyValueMap.get(key)
  }

  def getOptionalStringValue(key:String): String =
    if ( getOptionalValue(key) != None) {
      getOptionalValue(key).get
    }
    else {
      EMPTY
    }
}
