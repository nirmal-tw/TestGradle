package com.spike.ingestion.validator

import org.apache.spark.sql.DataFrame

class RecordCountFooterCountValidator extends Validator {
  override def validate(dataFrame: Map[String, DataFrame]): Map[String, DataFrame] = ???
}
