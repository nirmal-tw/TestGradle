package com.spike.ingestion.readers

import com.spike.ingestion.schema.JSONSchema
import com.spike.ingestion.util.{Constants, IOUtil}
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

 class IOHandler(sparkSession: SparkSession,iOUtil: IOUtil) {

   def getJSONSchema(schemaPath : String): Array[JSONSchema] ={
     import sparkSession.implicits._
     val schema = Encoders.product[JSONSchema].schema
     val schemaDf = iOUtil.readJSON(schemaPath,Option(schema)).as[JSONSchema]
     schemaDf.collect()
   }

   def readFixedWidthTextFile(filePath : String): DataFrame ={
     val df = iOUtil.read(filePath,Constants.TEXT_FORMAT,Map.empty[String, String],None)
     df
   }
}


