package com.spike.ingestion.util

import com.spike.ingestion.util.ArgumentKeys.{JOB_ID, JOB_NAME}


class Logger(name: String, jobId: String, jobName: String) {
  private val internalLogger = org.apache.log4j.Logger.getLogger(name)

  def trace(message: String): Unit = {
    internalLogger.trace(formatMessage(message))
  }

  def debug(message: String): Unit = {
    internalLogger.debug(formatMessage(message))
  }

  def error(message: String, exception: Exception = null): Unit = {
    internalLogger.error(formatMessage(message), exception)
  }

  def info(message: String): Unit = {
    internalLogger.info(formatMessage(message))
  }

  private def formatMessage(message: String): String = {
    String.format("%s\t%s\t%s", jobId, jobName, message)
  }
}

object Logger {
  var jobId: String = _
  var jobName: String = _

  def initialize(keyValueParser: KeyValueParser): Unit = {
    initialize(keyValueParser.getValue(JOB_ID), keyValueParser.getValue(JOB_NAME))
  }

  def initialize(jobId: String, jobName: String): Unit = {
    this.jobId = jobId
    this.jobName = jobName
  }

  def getLogger(clazz: Class[_]): Logger = {
    new Logger(clazz.getName, jobId, jobName)
  }
}