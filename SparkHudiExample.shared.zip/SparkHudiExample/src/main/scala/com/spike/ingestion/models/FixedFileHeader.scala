package com.spike.ingestion.models

case class FixedFileHeader(isAvaiable : Boolean, prefix : String)
