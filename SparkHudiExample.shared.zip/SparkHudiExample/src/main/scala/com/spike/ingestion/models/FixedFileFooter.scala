package com.spike.ingestion.models

case class FixedFileFooter(isAvaiable : Boolean, prefix : String)
