package com.spike.ingestion

import org.apache.hudi.DataSourceWriteOptions
import org.apache.hudi.config.HoodieWriteConfig
import org.apache.hudi.keygen.NonpartitionedKeyGenerator
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object HudiInsert {

  val userTableName = "user"
  val userRecordKeyField = "id"
  val userPrecombineField = "last_update_time"
  val userTablePath = "file:///tmp/user"

  def main(args: Array[String]): Unit = {
    val sparkSession = SparkSession.builder().appName("Hudi_ETL")
      .master("local")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .getOrCreate()
    val input_df = sparkSession.createDataFrame(Seq(
      ("100", "2015-01-01", "2015-01-01T13:51:39.340396Z"),
      ("101", "2015-01-01", "2015-01-01T12:14:58.597216Z"),
      ("102", "2015-01-01", "2015-01-01T13:51:40.417052Z"),
      ("103", "2015-01-01", "2015-01-01T13:51:40.519832Z"),
      ("104", "2015-01-02", "2015-01-01T12:15:00.512679Z"),
      ("105", "2015-01-02", "2015-01-01T13:51:42.248818Z"),
    )).toDF("id", "creation_date", "last_update_time")
    input_df.show(false)

    saveUserAsHudiWithoutHiveTableSync(input_df)

    //    val hudiOptions = Map[String,String](
    //      HoodieWriteConfig.TBL_NAME.key() -> "my_hudi_table",
    //      DataSourceWriteOptions.TABLE_TYPE.key() -> "COPY_ON_WRITE",
    //      DataSourceWriteOptions.RECORDKEY_FIELD.key() -> "id",
    //      DataSourceWriteOptions.PARTITIONPATH_FIELD.key() -> "creation_date",
    //      DataSourceWriteOptions.PRECOMBINE_FIELD.key()-> "last_update_time",
    //      DataSourceWriteOptions.META_SYNC_ENABLED.key() -> "true",
    //      DataSourceWriteOptions.HIVE_TABLE_OPT_KEY -> "my_hudi_table",
    //      DataSourceWriteOptions.HIVE_PARTITION_FIELDS_OPT_KEY -> "creation_date",
    //      DataSourceWriteOptions.HIVE_PARTITION_EXTRACTOR_CLASS_OPT_KEY -> classOf[MultiPartKeysValueExtractor].getName
    //    )

  }

  def saveUserAsHudiWithoutHiveTableSync(dataframe: DataFrame) = {

    val hudiOptions = Map[String, String](
      HoodieWriteConfig.TABLE_NAME -> userTableName,
      DataSourceWriteOptions.OPERATION_OPT_KEY -> DataSourceWriteOptions.UPSERT_OPERATION_OPT_VAL,
      DataSourceWriteOptions.TABLE_TYPE_OPT_KEY -> DataSourceWriteOptions.COW_TABLE_TYPE_OPT_VAL,
      DataSourceWriteOptions.RECORDKEY_FIELD_OPT_KEY -> userRecordKeyField,
      DataSourceWriteOptions.PRECOMBINE_FIELD_OPT_KEY -> userPrecombineField,
      DataSourceWriteOptions.KEYGENERATOR_CLASS_OPT_KEY -> classOf[NonpartitionedKeyGenerator].getName
    )

    dataframe
      .write
      .format("hudi")
      .options(hudiOptions)
      .mode(SaveMode.Append)
      .save(userTablePath)
  }
}
