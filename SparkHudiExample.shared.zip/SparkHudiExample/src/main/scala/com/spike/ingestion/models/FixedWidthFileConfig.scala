package com.spike.ingestion.models

case class FixedWidthFileConfig(input : FixedFileInput)
