package com.spike.ingestion.readers

import com.spike.ingestion.models.FixedWidthFileConfig
import com.spike.ingestion.util.ArgumentKeys._
import com.spike.ingestion.util._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import pureconfig.ConfigConvert.fromReaderAndWriter
import pureconfig._
import pureconfig.generic.ProductHint
import pureconfig.generic.auto._

class FixedWidthFileReaderDriver(ioHandler: IOHandler,keyValueParser: KeyValueParser, fixedWidthToDataframeTransformer : FixedWidthToDataframeTransformer){
  private val logger = Logger.getLogger(getClass)
  implicit def hint[A] = ProductHint[A](ConfigFieldMapping(CamelCase, CamelCase))

  //  private val jobId = keyValueParser.getValue(JOB_ID)
//  private val jobName = keyValueParser.getValue(JOB_NAME)
//  private val source = keyValueParser.getValue(SOURCE)


  def readFixedWidthAndTransform(implicit sparkSession: SparkSession): DataFrame ={

    val env = keyValueParser.getValue(ENV)
    val baseDir = keyValueParser.getOptionalStringValue(BASE_DIR)
    val fileReaderConfPath = keyValueParser.getOptionalStringValue(FIXED_WIDTH_FILE_READER_CONF_PATH)
    val configurationHelper = new ConfigurationHelper(env, baseDir,keyValueParser.keyValueMap,fileReaderConfPath)

    val fixedFileConfig = ConfigSource.fromConfig(configurationHelper.config).loadOrThrow[FixedWidthFileConfig]

    val schemaPathLocation = fixedFileConfig.input.inputFileSchemaPath
    val inputPathLocation = fixedFileConfig.input.inputFileLocation
    val schemaArr = ioHandler.getJSONSchema(schemaPathLocation)
    val df = ioHandler.readFixedWidthTextFile(inputPathLocation)
    //Header contains header &
    val dataMap = fixedWidthToDataframeTransformer.convertFixedWitdhDFToColumnDF(df,schemaArr, fixedFileConfig)
    val transformedDF = dataMap.get("data").get
    transformedDF.show()

    transformedDF
  }
}



object FixedWidthFileReaderDriver {

  def main(args: Array[String]): Unit = {
    val keyValueParser = new KeyValueParser(args)
    val source = keyValueParser.getValue(SOURCE)
    val env = keyValueParser.getValue(ENV)
    val baseDir = keyValueParser.getOptionalStringValue(BASE_DIR)
    val configurationHelper = new ConfigurationHelper(env, baseDir)
    val logger = Logger.getLogger(getClass)


    val sparkSessionFactory = new SparkSessionFactory(configurationHelper)
    implicit val spark: SparkSession = sparkSessionFactory.getSparkSession
    val ioUtil = new IOUtil()
    val ioHandler = new IOHandler(spark, ioUtil)
    val fixedWidthToDataframeTransformer = new FixedWidthToDataframeTransformer

    val fixedWidthReaderDriver = new FixedWidthFileReaderDriver(ioHandler, keyValueParser,fixedWidthToDataframeTransformer)
    try {
      fixedWidthReaderDriver.readFixedWidthAndTransform
    } catch {
      case e: org.apache.spark.sql.AnalysisException =>
        logger.error(s"Reader has failed with exception: ",e)
        throw e
    }
  }
}
