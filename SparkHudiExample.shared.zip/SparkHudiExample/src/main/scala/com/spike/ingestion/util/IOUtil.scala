package com.spike.ingestion.util

import com.spike.ingestion.schema.JSONSchema
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, DataFrameReader, Encoders, SparkSession}

class IOUtil(implicit sparkSession: SparkSession) {

  def read(paths: Seq[String], format: String, options: Map[String, String], schema: Option[StructType]): DataFrame = {
    val reader: DataFrameReader = buildReader(format, options, schema)
    reader.load(paths: _*)
  }



  def read(path: String, format: String, options: Map[String, String], schema: Option[StructType]): DataFrame = {
    val reader = buildReader(format, options, schema)
    reader.load(path)
  }

  private def buildReader(format: String, options: Map[String, String], schema: Option[StructType]) = {
    val reader = sparkSession.read
      .format(format)
      .options(options)

    if (schema.isDefined)
      reader.schema(schema.get)
    else
      reader
  }

  def readJSON(schemaPath : String, schema: Option[StructType]): DataFrame = {
    if (schema.isDefined)
      sparkSession.read.schema(schema.get).json(schemaPath)
    else
      sparkSession.read.json(schemaPath)


  }
}
