package com.spike.ingestion.validator

import com.spike.ingestion.util.ValidatorConstants.RECORD_COUNT_SHOULD_MATCH_FOOTER_COUNT

object ValidatorFactory {

  def getValidator(validatorType : String): Validator ={

    validatorType match {
      case RECORD_COUNT_SHOULD_MATCH_FOOTER_COUNT =>
        new RecordCountFooterCountValidator()
    }
  }
}
