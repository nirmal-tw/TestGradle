package com.spike.ingestion.validator

import org.apache.spark.sql.DataFrame

trait Validator {
  def validate(dataFrame: Map[String, DataFrame]): Map[String, DataFrame]
}
