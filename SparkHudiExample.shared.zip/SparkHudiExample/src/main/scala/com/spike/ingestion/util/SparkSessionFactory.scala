package com.spike.ingestion.util

import com.spike.ingestion.util.Constants.{APP_NAME, SPARK}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession


class SparkSessionFactory(configurationHelper: ConfigurationHelper) {

  def getSparkSession: SparkSession = {
    val conf: SparkConf = getSparkConf
    conf.set("spark.sql.caseSensitive", "true")
    val sparkSession = SparkSession.builder()
      .appName(APP_NAME)
      .config(conf)
      .getOrCreate()
    // TODO: Can set log level dynamically here : sparkSession.sparkContext.setLogLevel("")
    sparkSession
  }

  def getLocalHiveSparkSession :SparkSession = {
    val conf: SparkConf = getSparkConf
    val sparkSession = SparkSession.builder()
    .appName(APP_NAME)
      .master("local[*]")
    .config(conf)
      .enableHiveSupport()
    .getOrCreate()
    // TODO: Can set log level dynamically here : sparkSession.sparkContext.setLogLevel("")
    sparkSession
  }

  def getHiveSparkSession: SparkSession = {
    val conf: SparkConf = getSparkConf
    val sparkSession = SparkSession.builder()
      .config(conf)
      .enableHiveSupport()
      .appName(APP_NAME)
      .getOrCreate()
    // TODO: Can set log level dynamically here : sparkSession.sparkContext.setLogLevel("")
    sparkSession
  }

  private def getSparkConf = {
    val conf = new SparkConf()
    val properties = configurationHelper.getPropertiesBundle(SPARK)
    val itr = properties.keys()
    while (itr.hasMoreElements) {
      val key = itr.nextElement().toString
      val value = properties.getProperty(key)
      conf.set(key, value)
    }
    conf
  }

}
