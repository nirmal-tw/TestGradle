package com.spike.ingestion.models

case class FixedFileInput(inputFileLocation : String, inputFileSchemaPath : String, header : FixedFileHeader, footer: FixedFileFooter)

